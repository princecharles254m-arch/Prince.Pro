# Deriv setup

PrincePro is structured to use Deriv's current API architecture.

## 1. Create a Deriv API application

Create an application in your Deriv developer/API area and register an HTTPS redirect URI for OAuth.

For a web OAuth flow, use OAuth 2.0 Authorization Code + PKCE.

The backend in this repository exposes:

- `GET /auth/url` — creates the authorization URL
- `GET /auth/callback` — exchanges the returned code
- `GET /health` — health check

Do not put a client secret or long-lived token in Flutter source code.

## 2. Environment variables

```env
PORT=8787
DERIV_CLIENT_ID=YOUR_CLIENT_ID
DERIV_CLIENT_SECRET=YOUR_CLIENT_SECRET
DERIV_REDIRECT_URI=https://YOUR_DOMAIN/auth/callback
FLUTTER_APP_URL=princepro://oauth
```

The exact redirect URI must match the one registered with Deriv.

## 3. Public market data

The Flutter app uses the public Deriv WebSocket for market data. No account token is required for public ticks.

The market service requests:

- `active_symbols`
- `ticks`
- `ticks_history`

## 4. Authenticated trading

For real/demo account operations, the backend should obtain an authenticated WebSocket URL through the Deriv account OTP flow after the user authorizes the app.

The authenticated connection can then be used for:

- balance/account information
- proposals
- buy
- open contract monitoring
- sell
- portfolio

## 5. Recommended rollout

1. Demo UI
2. Public live ticks
3. Demo-account authentication
4. Proposal preview
5. Demo buy
6. Open-contract monitoring
7. Real-account authorization
8. Real trading behind explicit confirmation

Do not skip the demo stages.
