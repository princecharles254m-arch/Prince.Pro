# Build PrincePro from an Android phone

The easiest route is to upload this repository to GitHub and use a cloud development/build environment.

## GitHub

Create a repository named `princepro`, upload the contents of `flutter_app` as the Flutter project, and keep `backend` as a sibling folder if you want the API server in the same repository.

## Cloud build

Use any Flutter-capable cloud IDE/CI service. The project is intentionally standard Flutter and does not depend on Android Studio.

## Local Android build

If you later have access to a computer:

```bash
cd flutter_app
flutter pub get
flutter build apk --release
```

The generated APK will be under:

`build/app/outputs/flutter-apk/app-release.apk`

## Before real trading

Keep Demo Mode enabled until:

- Deriv app registration is complete
- OAuth redirect is HTTPS and exact
- authenticated WebSocket connection is tested
- proposal responses are validated
- demo buy/monitor/sell is tested
- risk limits and confirmation UX are verified
