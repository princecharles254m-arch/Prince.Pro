import 'package:flutter/material.dart';
import 'core/app_theme.dart';
import 'screens/splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PrinceProApp());
}

class PrinceProApp extends StatelessWidget {
  const PrinceProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PrincePro',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      home: const SplashScreen(),
    );
  }
}
