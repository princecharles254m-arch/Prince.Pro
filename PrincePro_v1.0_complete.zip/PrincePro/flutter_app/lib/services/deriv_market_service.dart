import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../models/market.dart';

class DerivMarketService {
  static const publicUrl =
      'wss://api.derivws.com/trading/v1/options/ws/public';

  WebSocketChannel? _channel;
  StreamSubscription? _sub;
  final _markets = StreamController<Market>.broadcast();
  final Map<String, Market> _cache = {};

  Stream<Market> get marketStream => _markets.stream;

  Future<void> connect(String symbol) async {
    await disconnect();
    try {
      _channel = WebSocketChannel.connect(Uri.parse(publicUrl));
      _sub = _channel!.stream.listen(
        (raw) {
          final data = jsonDecode(raw as String);
          if (data['msg_type'] == 'tick') {
            final tick = data['tick'];
            final quote = (tick['quote'] as num).toDouble();
            final old = _cache[symbol] ??
                Market(
                  symbol: symbol,
                  displayName: _name(symbol),
                  category: 'Synthetic Indices',
                  price: quote,
                  change: 0,
                  ticks: [quote],
                );
            final ticks = [...old.ticks, quote];
            if (ticks.length > 80) ticks.removeAt(0);
            final change = old.price == 0
                ? 0
                : ((quote - old.price) / old.price) * 100;
            final updated = old.copyWith(
              price: quote,
              change: change,
              ticks: ticks,
            );
            _cache[symbol] = updated;
            _markets.add(updated);
          }
        },
        onError: (_) => _startSimulation(symbol),
        onDone: () => _startSimulation(symbol),
      );
      _channel!.sink.add(jsonEncode({
        'ticks': symbol,
        'subscribe': 1,
        'req_id': 1,
      }));
    } catch (_) {
      _startSimulation(symbol);
    }
  }

  void _startSimulation(String symbol) {
    Timer.periodic(const Duration(milliseconds: 900), (timer) {
      if (_channel != null) timer.cancel();
      final random = Random();
      final old = _cache[symbol] ??
          Market(
            symbol: symbol,
            displayName: _name(symbol),
            category: 'Synthetic Indices',
            price: 100000,
            change: 0,
            ticks: const [100000],
          );
      final next = old.price + (random.nextDouble() - .48) * old.price * .0008;
      final ticks = [...old.ticks, next];
      if (ticks.length > 80) ticks.removeAt(0);
      final updated = old.copyWith(
        price: next,
        change: ((next - old.price) / old.price) * 100,
        ticks: ticks,
      );
      _cache[symbol] = updated;
      _markets.add(updated);
    });
  }

  Future<void> disconnect() async {
    await _sub?.cancel();
    _sub = null;
    await _channel?.sink.close();
    _channel = null;
  }

  String _name(String symbol) {
    const names = {
      '1HZ75V': 'Volatility 75 Index',
      '1HZ100V': 'Volatility 100 (1s) Index',
      'R_10': 'Volatility 10 Index',
      'BOOM500': 'Boom 500 Index',
      'CRASH500': 'Crash 500 Index',
    };
    return names[symbol] ?? symbol;
  }

  void dispose() {
    disconnect();
    _markets.close();
  }
}
