import 'dart:math';
import '../models/market.dart';
import '../models/signal.dart';

class SignalEngine {
  Signal generate(Market market, ContractKind kind) {
    final ticks = market.ticks.length < 8
        ? [...market.ticks, ...List.filled(8 - market.ticks.length, market.price)]
        : market.ticks;
    final fast = _sma(ticks, min(5, ticks.length));
    final slow = _sma(ticks, min(12, ticks.length));
    final momentum = ticks.last - ticks[max(0, ticks.length - 6)];
    final direction = fast >= slow && momentum >= 0 ? 'RISE' : 'FALL';
    var confidence = 50;
    if ((fast - slow).abs() > market.price * .00015) confidence += 12;
    if (momentum.abs() > market.price * .0002) confidence += 10;
    confidence += (Random(market.symbol.hashCode).nextInt(8));
    confidence = confidence.clamp(50, 92);

    final reasons = <String>[
      fast >= slow ? 'Fast trend is above slow trend' : 'Fast trend is below slow trend',
      momentum >= 0 ? 'Recent momentum is positive' : 'Recent momentum is negative',
      'Tick stream and short-term trend agree',
    ];

    String action = direction;
    if (kind == ContractKind.matchesDiffers) {
      action = confidence >= 70 ? 'DIFFERS' : 'MATCHES';
    } else if (kind == ContractKind.evenOdd) {
      action = ticks.last.round().isEven ? 'EVEN' : 'ODD';
    } else if (kind == ContractKind.overUnder) {
      action = ticks.last % 10 >= 5 ? 'OVER' : 'UNDER';
    }

    return Signal(
      market: market.displayName,
      kind: kind,
      direction: action,
      confidence: confidence,
      strength: confidence >= 80 ? 'STRONG' : confidence >= 65 ? 'MODERATE' : 'WEAK',
      duration: '5 Ticks',
      reasons: reasons,
    );
  }

  double _sma(List<double> values, int n) =>
      values.skip(max(0, values.length - n)).reduce((a, b) => a + b) / n;
}
