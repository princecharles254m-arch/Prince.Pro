import 'package:flutter/material.dart';

class AppTheme {
  static const bg = Color(0xFF050616);
  static const panel = Color(0xFF0B0B25);
  static const panel2 = Color(0xFF111033);
  static const purple = Color(0xFF8A2BE2);
  static const cyan = Color(0xFF12D8FA);
  static const green = Color(0xFF19E68C);
  static const red = Color(0xFFFF4B5C);

  static ThemeData dark() => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bg,
    colorScheme: ColorScheme.fromSeed(
      seedColor: purple,
      brightness: Brightness.dark,
    ),
    fontFamily: 'Roboto',
    cardColor: panel,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: panel,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
    ),
  );
}
