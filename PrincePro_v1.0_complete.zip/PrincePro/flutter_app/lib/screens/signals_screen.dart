import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../models/market.dart';
import '../models/signal.dart';
import '../services/signal_engine.dart';
import '../widgets/glow_card.dart';

class SignalsScreen extends StatelessWidget {
  const SignalsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final market = Market(symbol: '1HZ75V', displayName: 'Volatility 75 Index', category: 'Synthetic', price: 254943, change: .4, ticks: List.generate(30, (i) => 254900 + i * 3.0));
    final kinds = ContractKind.values;
    return SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Signals Hub', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('Analysis across supported contract categories', style: TextStyle(color: Colors.white54)),
      const SizedBox(height: 16),
      ...kinds.map((kind) {
        final s = SignalEngine().generate(market, kind);
        return Padding(padding: const EdgeInsets.only(bottom: 12), child: GlowCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text(_label(kind), style: const TextStyle(fontWeight: FontWeight.bold))), Text('${s.confidence}%', style: const TextStyle(color: AppTheme.cyan, fontWeight: FontWeight.bold))]),
          const SizedBox(height: 8),
          Text(s.direction, style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: s.direction == 'FALL' ? AppTheme.red : AppTheme.green)),
          const SizedBox(height: 8),
          Text(s.strength, style: const TextStyle(color: Colors.white54)),
          const SizedBox(height: 8),
          ...s.reasons.map((r) => Text('• $r', style: const TextStyle(color: Colors.white70))),
        ])));
      }),
      const SizedBox(height: 8),
      const Text('Signals are analytical scores, not guaranteed outcomes.', style: TextStyle(color: Colors.white38, fontSize: 12)),
    ]));
  }

  String _label(ContractKind k) => switch (k) {
    ContractKind.riseFall => 'Rise / Fall',
    ContractKind.matchesDiffers => 'Matches / Differs',
    ContractKind.evenOdd => 'Even / Odd',
    ContractKind.overUnder => 'Over / Under',
  };
}
