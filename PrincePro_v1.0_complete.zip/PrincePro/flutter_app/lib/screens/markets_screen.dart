import 'dart:async';
import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../models/market.dart';
import '../services/deriv_market_service.dart';
import '../widgets/glow_card.dart';
import '../widgets/mini_chart.dart';

class MarketsScreen extends StatefulWidget {
  const MarketsScreen({super.key});
  @override State<MarketsScreen> createState() => _MarketsScreenState();
}
class _MarketsScreenState extends State<MarketsScreen> {
  final service = DerivMarketService();
  final symbols = const ['1HZ75V', '1HZ100V', 'R_10', 'BOOM500', 'CRASH500'];
  final Map<String, Market> markets = {};
  StreamSubscription? sub;

  @override
  void initState() {
    super.initState();
    for (final s in symbols) service.connect(s);
    sub = service.marketStream.listen((m) => setState(() => markets[m.symbol] = m));
  }
  @override
  void dispose() {
    sub?.cancel();
    service.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Markets', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('Live public market feed', style: TextStyle(color: Colors.white54)),
      const SizedBox(height: 16),
      TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search market')),
      const SizedBox(height: 14),
      ...symbols.map((s) {
        final m = markets[s];
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: GlowCard(child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(m?.displayName ?? s, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(m == null ? 'Connecting…' : m.price.toStringAsFixed(2), style: const TextStyle(color: Colors.white70)),
            ])),
            SizedBox(width: 100, child: MiniChart(values: m?.ticks ?? const [])),
            const SizedBox(width: 10),
            Text(
              m == null ? '--' : '${m.change >= 0 ? '+' : ''}${m.change.toStringAsFixed(2)}%',
              style: TextStyle(color: m == null ? Colors.white54 : (m.change >= 0 ? AppTheme.green : AppTheme.red)),
            ),
          ])),
        );
      }),
    ]),
  );
}
