import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../widgets/glow_card.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  @override
  Widget build(BuildContext context) => SafeArea(
    child: ListView(padding: const EdgeInsets.all(16), children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Dashboard', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          Text('Demo Account', style: TextStyle(color: Colors.white54)),
        ]),
        IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
      ]),
      const SizedBox(height: 16),
      GlowCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Account Balance', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 8),
        const Text('\$5,432.19', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('+10.87% today', style: TextStyle(color: AppTheme.green)),
      ])),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: _stat('Total Profit', '\$1,240.45', AppTheme.green)),
        const SizedBox(width: 10),
        Expanded(child: _stat('Win Rate', '68.4%', AppTheme.cyan)),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: _stat('Total Trades', '128', Colors.white)),
        const SizedBox(width: 10),
        Expanded(child: _stat('Signals', '24', AppTheme.purple)),
      ]),
      const SizedBox(height: 16),
      GlowCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Recent Signals', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        _signal('Volatility 75 Index', 'RISE', '82%', AppTheme.green),
        _signal('Boom 500 Index', 'FALL', '76%', AppTheme.red),
        _signal('Volatility 100 Index', 'RISE', '71%', AppTheme.green),
      ])),
    ]),
  );

  Widget _stat(String title, String value, Color color) => GlowCard(
    padding: const EdgeInsets.all(14),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: Colors.white54, fontSize: 12)),
      const SizedBox(height: 8),
      Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
    ]),
  );

  Widget _signal(String market, String dir, String conf, Color color) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(children: [
      Icon(dir == 'RISE' ? Icons.trending_up : Icons.trending_down, color: color),
      const SizedBox(width: 10),
      Expanded(child: Text(market)),
      Text('$dir  $conf', style: TextStyle(color: color, fontWeight: FontWeight.bold)),
    ]),
  );
}
