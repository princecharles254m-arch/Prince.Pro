import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../models/market.dart';
import '../services/signal_engine.dart';
import '../models/signal.dart';
import '../widgets/glow_card.dart';

class TradeScreen extends StatefulWidget {
  const TradeScreen({super.key});
  @override State<TradeScreen> createState() => _TradeScreenState();
}
class _TradeScreenState extends State<TradeScreen> {
  String market = 'Volatility 75 Index';
  ContractKind kind = ContractKind.riseFall;
  double stake = 5;
  @override
  Widget build(BuildContext context) {
    final demoMarket = Market(symbol: '1HZ75V', displayName: market, category: 'Synthetic', price: 254943.21, change: .45, ticks: List.generate(30, (i) => 254800 + i * 5.0));
    final signal = SignalEngine().generate(demoMarket, kind);
    return SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Trade', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      GlowCard(child: Column(children: [
        DropdownButtonFormField<String>(
          value: market,
          decoration: const InputDecoration(labelText: 'Market'),
          items: const [
            DropdownMenuItem(value: 'Volatility 75 Index', child: Text('Volatility 75 Index')),
            DropdownMenuItem(value: 'Volatility 100 (1s) Index', child: Text('Volatility 100 (1s) Index')),
            DropdownMenuItem(value: 'Boom 500 Index', child: Text('Boom 500 Index')),
          ],
          onChanged: (v) => setState(() => market = v!),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<ContractKind>(
          value: kind,
          decoration: const InputDecoration(labelText: 'Contract type'),
          items: const [
            DropdownMenuItem(value: ContractKind.riseFall, child: Text('Rise / Fall')),
            DropdownMenuItem(value: ContractKind.matchesDiffers, child: Text('Matches / Differs')),
            DropdownMenuItem(value: ContractKind.evenOdd, child: Text('Even / Odd')),
            DropdownMenuItem(value: ContractKind.overUnder, child: Text('Over / Under')),
          ],
          onChanged: (v) => setState(() => kind = v!),
        ),
        const SizedBox(height: 12),
        Text('Stake: \$${stake.toStringAsFixed(2)}'),
        Slider(value: stake, min: 1, max: 100, divisions: 99, onChanged: (v) => setState(() => stake = v)),
      ])),
      const SizedBox(height: 16),
      GlowCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('PrincePro Signal', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Text(signal.direction, style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: signal.direction == 'FALL' ? AppTheme.red : AppTheme.green)),
        Text('${signal.confidence}% ${signal.strength}', style: const TextStyle(color: AppTheme.cyan)),
        const SizedBox(height: 12),
        ...signal.reasons.map((r) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [const Icon(Icons.check_circle, size: 16, color: AppTheme.green), const SizedBox(width: 8), Expanded(child: Text(r))]))),
      ])),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppTheme.green, foregroundColor: Colors.black),
          onPressed: () => _confirm(context, 'RISE'),
          child: const Text('RISE'),
        )),
        const SizedBox(width: 12),
        Expanded(child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppTheme.red),
          onPressed: () => _confirm(context, 'FALL'),
          child: const Text('FALL'),
        )),
      ]),
    ]));
  }

  void _confirm(BuildContext context, String side) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: Text('Confirm $side'),
      content: Text('Demo order only. Stake \$${stake.toStringAsFixed(2)} on $market?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () { Navigator.pop(context); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo trade recorded.'))); }, child: const Text('Confirm')),
      ],
    ));
  }
}
