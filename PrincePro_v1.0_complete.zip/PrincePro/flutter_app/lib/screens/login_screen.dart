import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../widgets/glow_card.dart';
import 'home_shell.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Spacer(),
          const Text('Welcome to', style: TextStyle(fontSize: 18)),
          const SizedBox(height: 4),
          RichText(text: const TextSpan(
            style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
            children: [TextSpan(text: 'Prince'), TextSpan(text: 'Pro', style: TextStyle(color: AppTheme.cyan))],
          )),
          const SizedBox(height: 8),
          const Text('Connect your Deriv account or explore demo mode.', style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 28),
          GlowCard(child: Column(children: [
            SizedBox(width: double.infinity, child: FilledButton.icon(
              icon: const Icon(Icons.login),
              label: const Text('Sign in with Deriv'),
              onPressed: () => _showAuthInfo(context),
            )),
            const SizedBox(height: 14),
            const Text('or', style: TextStyle(color: Colors.white38)),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: OutlinedButton(
              onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeShell())),
              child: const Text('Continue in Demo Mode'),
            )),
          ])),
          const Spacer(),
          const Center(child: Text('Never share your Deriv password with PrincePro.', style: TextStyle(color: Colors.white38, fontSize: 12))),
        ]),
      ),
    ),
  );

  void _showAuthInfo(BuildContext context) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Deriv authorization'),
      content: const Text('The project includes the OAuth backend scaffold. Add your registered Deriv client ID and HTTPS redirect URI in the backend, then connect the app to that backend.'),
      actions: [TextButton(onPressed: () {
        Navigator.pop(context);
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeShell()));
      }, child: const Text('Continue Demo'))],
    ));
  }
}
