import 'dart:async';
import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import 'login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    });
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(colors: [Color(0xFF03030E), Color(0xFF0D0320)]),
      ),
      child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          width: 100, height: 100,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: const LinearGradient(colors: [AppTheme.purple, AppTheme.cyan]),
          ),
          child: const Center(child: Text('P', style: TextStyle(fontSize: 62, fontWeight: FontWeight.w900))),
        ),
        const SizedBox(height: 22),
        RichText(text: const TextSpan(
          style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800),
          children: [TextSpan(text: 'Prince'), TextSpan(text: 'Pro', style: TextStyle(color: AppTheme.cyan))],
        )),
        const SizedBox(height: 8),
        const Text('Trade Smarter. Trade Faster.', style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 30),
        const CircularProgressIndicator(),
      ])),
    ),
  );
}
