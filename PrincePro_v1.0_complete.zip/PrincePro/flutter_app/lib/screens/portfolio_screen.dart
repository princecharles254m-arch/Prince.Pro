import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../widgets/glow_card.dart';

class PortfolioScreen extends StatelessWidget {
  const PortfolioScreen({super.key});
  @override
  Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Portfolio', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 16),
    GlowCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Demo account', style: TextStyle(color: Colors.white54)),
      const SizedBox(height: 8),
      const Text('\$5,432.19', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text('+ \$1,240.45 profit', style: TextStyle(color: AppTheme.green)),
    ])),
    const SizedBox(height: 16),
    const Text('Recent Trades', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    const SizedBox(height: 10),
    ...[
      ('Volatility 75 Index', 'RISE', '+\$4.50', AppTheme.green),
      ('Boom 500 Index', 'FALL', '-\$5.00', AppTheme.red),
      ('Crash 500 Index', 'RISE', '+\$4.35', AppTheme.green),
      ('Volatility 100 Index', 'FALL', '-\$5.00', AppTheme.red),
    ].map((t) => Padding(padding: const EdgeInsets.only(bottom: 8), child: GlowCard(child: Row(children: [
      Expanded(child: Text(t.$1)),
      Text(t.$2, style: TextStyle(color: t.$4, fontWeight: FontWeight.bold)),
      const SizedBox(width: 12),
      Text(t.$3, style: TextStyle(color: t.$4)),
    ])))),
  ]));
}
