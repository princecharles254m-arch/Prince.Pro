class Market {
  final String symbol;
  final String displayName;
  final String category;
  final double price;
  final double change;
  final List<double> ticks;

  const Market({
    required this.symbol,
    required this.displayName,
    required this.category,
    required this.price,
    required this.change,
    this.ticks = const [],
  });

  Market copyWith({double? price, double? change, List<double>? ticks}) =>
      Market(
        symbol: symbol,
        displayName: displayName,
        category: category,
        price: price ?? this.price,
        change: change ?? this.change,
        ticks: ticks ?? this.ticks,
      );
}
