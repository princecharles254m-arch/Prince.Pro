enum ContractKind { riseFall, matchesDiffers, evenOdd, overUnder }

class Signal {
  final String market;
  final ContractKind kind;
  final String direction;
  final int confidence;
  final String strength;
  final String duration;
  final List<String> reasons;
  final DateTime time;

  Signal({
    required this.market,
    required this.kind,
    required this.direction,
    required this.confidence,
    required this.strength,
    required this.duration,
    required this.reasons,
    DateTime? time,
  }) : time = time ?? DateTime.now();
}
