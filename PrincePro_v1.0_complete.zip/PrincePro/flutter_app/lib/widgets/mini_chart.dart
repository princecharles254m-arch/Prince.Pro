import 'package:flutter/material.dart';
import '../core/app_theme.dart';

class MiniChart extends StatelessWidget {
  final List<double> values;
  const MiniChart({super.key, required this.values});

  @override
  Widget build(BuildContext context) => SizedBox(
    height: 65,
    child: CustomPaint(
      painter: _ChartPainter(values),
      child: const SizedBox.expand(),
    ),
  );
}

class _ChartPainter extends CustomPainter {
  final List<double> values;
  _ChartPainter(this.values);

  @override
  void paint(Canvas canvas, Size size) {
    if (values.length < 2) return;
    final minV = values.reduce((a,b) => a < b ? a : b);
    final maxV = values.reduce((a,b) => a > b ? a : b);
    final range = (maxV - minV).abs() < 1e-9 ? 1 : maxV - minV;
    final p = Paint()
      ..color = AppTheme.purple
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = i * size.width / (values.length - 1);
      final y = size.height - ((values[i] - minV) / range) * size.height;
      if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
    }
    canvas.drawPath(path, p);
  }

  @override
  bool shouldRepaint(covariant _ChartPainter old) => old.values != values;
}
