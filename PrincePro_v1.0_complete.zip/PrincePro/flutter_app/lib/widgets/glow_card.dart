import 'package:flutter/material.dart';
import '../core/app_theme.dart';

class GlowCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const GlowCard({super.key, required this.child, this.padding = const EdgeInsets.all(16)});

  @override
  Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: BoxDecoration(
      color: AppTheme.panel,
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: AppTheme.purple.withOpacity(.25)),
      boxShadow: [BoxShadow(color: AppTheme.purple.withOpacity(.08), blurRadius: 24)],
    ),
    child: child,
  );
}
