# PrincePro

PrincePro is a Flutter trading-analysis application designed around the supplied PrincePro UI reference.

## Included

- Flutter Android/iOS/web-ready app structure
- Dark neon PrincePro UI
- Splash, login, dashboard, markets, trade, signals, portfolio, history, settings
- Live public Deriv market-data WebSocket service
- Tick streaming and custom chart rendering
- Local demo mode so the UI works without credentials
- Signal engine for Rise/Fall, Matches/Differs, Even/Odd and Over/Under
- Risk controls and a confirmation step before any live trade action
- Node/Express backend scaffold for OAuth token exchange and authenticated Deriv WebSocket OTP
- `.env.example` and setup instructions

## Important

The app does not invent live account balances or execute real trades by default. Real trading requires your own Deriv application credentials and user authorization. Configure those only after testing in demo mode.

## Quick start

### Flutter

1. Install Flutter.
2. Open `flutter_app`.
3. Run:
   `flutter pub get`
4. Run:
   `flutter run`

The app starts in Demo Mode. Tap Markets to see simulated/live-public market data.

### Backend

1. Install Node.js 20+.
2. Copy `backend/.env.example` to `backend/.env`.
3. Put your Deriv OAuth client settings in `.env`.
4. Run:
   `cd backend`
   `npm install`
   `npm start`

See `docs/DERIV_SETUP.md`.

## Safety

PrincePro signals are analytical outputs, not guarantees of profit. A displayed confidence score is a model score, not a probability of winning. Never use martingale as a guarantee against losses.
