import express from 'express';
import cors from 'cors';
import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const port = process.env.PORT || 8787;
const sessions = new Map();

function base64url(input) {
  return Buffer.from(input).toString('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function pkceChallenge(verifier) {
  return base64url(crypto.createHash('sha256').update(verifier).digest());
}

app.get('/health', (_, res) => res.json({ ok: true, service: 'PrincePro' }));

app.get('/auth/url', (_, res) => {
  const state = base64url(crypto.randomBytes(24));
  const verifier = base64url(crypto.randomBytes(48));
  sessions.set(state, { verifier, createdAt: Date.now() });

  const params = new URLSearchParams({
    response_type: 'code',
    client_id: process.env.DERIV_CLIENT_ID || '',
    redirect_uri: process.env.DERIV_REDIRECT_URI || '',
    scope: 'trade',
    state,
    code_challenge: pkceChallenge(verifier),
    code_challenge_method: 'S256',
  });

  res.json({ url: `https://auth.deriv.com/oauth2/auth?${params.toString()}`, state });
});

app.get('/auth/callback', async (req, res) => {
  const { code, state } = req.query;
  const session = sessions.get(state);
  if (!code || !session) return res.status(400).send('Invalid or expired authorization request.');
  sessions.delete(state);

  const body = new URLSearchParams({
    grant_type: 'authorization_code',
    client_id: process.env.DERIV_CLIENT_ID || '',
    client_secret: process.env.DERIV_CLIENT_SECRET || '',
    code,
    code_verifier: session.verifier,
    redirect_uri: process.env.DERIV_REDIRECT_URI || '',
  });

  try {
    const response = await fetch('https://auth.deriv.com/oauth2/token', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body,
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json(data);

    // In production, persist the session server-side and redirect using a short-lived
    // one-time code. Do not put the access token into a URL.
    res.json({ message: 'Authorization successful', token_type: data.token_type, expires_in: data.expires_in });
  } catch (e) {
    res.status(500).json({ error: 'Token exchange failed' });
  }
});

app.listen(port, () => console.log(`PrincePro backend listening on ${port}`));
